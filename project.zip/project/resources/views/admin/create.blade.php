@extends('layout.master')
@section('title','Registetion Form')
@section('content')


<body>
	<form method="post">
		<input type="hidden" name="_token" value="{{csrf_token()}}">

		<table class="table table-striped" width="100">
			<tr>
				<td>Full Name</td>
				<td><input type="text" name="name" value="{{old('name')}}"></td>
			</tr>
			<tr>
				<td>Contact No</td>
				<td><input type="text" name="contactno" value="{{old('contactno')}}"></td>
			</tr>
			<tr>
				<td>User Name</td>
				<td><input type="text" name="username" value="{{old('username')}}"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="password" value="{{old('password')}}"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="email" name="email" value="{{old('email')}}"></td>
				</tr>
			<tr>
				<td>Gender</td>
				<td><input type="text" name="gender" value="{{old('gender')}}"></td>
				</tr>
			<tr>
			<tr>
				<td>Address</td>
				<td><input type="text" name="address" value="{{old('address')}}"></td>
			</tr>
				<td>Type</td>
				<td><input type="text" name="type" value="{{old('usertype')}}"></td>
			</tr>
			
			 <tr>
				<td>Profile Picture</td>
				<td><input type="file" name="img" ></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>

		      <a href="{{route('admin.home')}}">Back</a>
	</form>
	<div>
		@foreach($errors->all() as $err)
			{{$err}} <br>
		@endforeach
	</div>
</body>

@endsection